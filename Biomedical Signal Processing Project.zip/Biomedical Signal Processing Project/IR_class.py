
'''
AIMS, March 2011.  Biomedical Signal Processing Course


plotting response as defined by difference equation:
y[n] = SUM{k=-inf:inf}(x[k]*h[n-k])


Student editing to be done:  
+ write the loop below to do the convolution of input with input with impulse response

++ bonus:  show that convolution is commutative by writing the convolution as both y=x*h and y=h*x!

'''

# import as necessary
#from __future__ import division
from scipy import *
from pylab import *
from matplotlib import *


def make_x(n):
    ''' 
    this is our specific 'input signal', which we can 
    make whatever we want
    '''
    # a possible input
    if( n<0 ):
        out = 0
    elif( n<3):
        out = 1.0
    else:
        out = 0
    return out

def make_h(n):
    ''' a way to write an impulse response function'''
    IR = [1.,2.,1.]
    IR/= sum(IR) 
    ## ?? what might be nice about dividing by SUM(IR)?

    if( n<0 ):
        return 0
    elif( n<len(IR)):
        return IR[n]
    else:
        return 0



# main ===============================================
if __name__ == "__main__":
    
    # define range of n's to walk through; should only have y>0 for n>=0
    NMAX = 15
    ns = arange(0,NMAX+1) # our array of n's

    # make an array of zeros which will be filled in 
    # for the x[n-k] and y[n-k], should have same number of 
    # spaces as our n's to test
    y = zeros(len(ns),dtype=float)
    # to record our x-inputs
    x = zeros(len(ns),dtype=float)
    # for showing h[n]
    h = zeros(len(ns),dtype=float)

    ################
    
    # make arrays of input and IR
    for n in ns: 
        x[n] = make_x(n)
        h[n] = make_h(n)

    # Convolution Eq;  y[n] = SUM x[k]*h[n-k]
        # DO!!!!! ???????????????
        # Q: what are possible limits for the summation?



    # xlimits of plot
    absci = [-0.5, NMAX+0.5]

    subplot(311)
    xlabel( "n") 
    ylabel( "x[n]")
    xlim(absci)
    ylim([1.2*min(x)-0.1, 1.2*max(x)+0.1])
    stem(ns,x, linefmt='k-', markerfmt='bo', basefmt='k-')

    # plots
    subplot(312)
    xlabel( "n") # these plot format commands must be *below* 'subplot',
                 # as I was kindly informed by AIMS students
    ylabel( "h[n]")
    xlim(absci)
    ylim([1.2*min(h)-0.1, 1.2*max(h)+0.1]) # guess at suitable height of y-axes
    stem(ns,h,linefmt='k-', markerfmt='ro', basefmt='k-')

    subplot(313)
    xlabel( "n")
    ylabel( "?????y[n]??????")
    xlim(absci)
    ylim([1.2*min(y)-0.1, 1.2*max(y)+0.1])
    stem(ns,y,linefmt='k-', markerfmt='go', basefmt='k-')

    show()
