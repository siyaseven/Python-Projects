import sys
import fileinput
USAGE = """USAGE: SF_matrix.py <file>

Input:
(1)The name of a file containing the MCL information

Output:
SF_matrix where:
columns = 11 fungal species
rows = 30684 gene families
entries(i,j) = number of genes family j has in gene family i
"""

# Parse the command line.
MCLFileName = sys.argv[1]  #file containing MCL results

species = 11
genefamilies = 32278
genefamily_numbers = range(genefamilies + 1)

codes = ["Gene_family_number","CC","CH","CN","FG","HC","NC","or","PA","PG","PT","SP"] #codes of 11 gene families for first row

def make_list(size):
    """create a list of size number of zeros"""
    mylist = []
    for i in range(size):
        mylist.append(0)
    return mylist

def make_matrix(rows, cols):
    """
    create a 2D matrix as a list of rows number of lists
    where the lists are cols in size
    resulting matrix contains zeros
    """
    matrix = []

    for i in range(rows):
        matrix.append(make_list(cols))
    return matrix

SFmatrix = make_matrix((genefamilies+1),(species+1)) #initializing my SFmatrix

#inserting the first column as the gene family numbers
for i in genefamily_numbers:
    SFmatrix[i][0]=i
#assigning the specie names to the first row
SFmatrix[0]=codes


data_SFM = open("matrixSF","w")
names = ["CC","CH","CN","FG","HC","NC","or","PA","PG","PT","SP"] #names of 11 gene families

#make dictionary where key=(Specie code,Gene family) and value=(count)
SFM_dictionary = {} # Key =(Specie code,Gene family), value = count of each specie in each gene family

#reading over MCL output and counting the number of instances of each fungi specie in each gene family
geneFamily = 1
test = 0
for line in fileinput.input(MCLFileName):
    data = line.rstrip().split()
    tt = len(data) #the number of genes in each gene family
    data_SFM.write(str(tt)+'\n' )
    for name in names:
    #for gene in data:
        #print gene
        count = 0
        for gene in data:
        #for name in names:
            #print name
            if gene[:2]==name:
                count +=1
            #print count
            SFM_dictionary[(name,geneFamily)] = float(count)
            #print SFM_dictionary[(name,geneFamily)]
            SFmatrix[geneFamily][((names.index(name)+1))]=SFM_dictionary[(name,geneFamily)]
    geneFamily +=1
    test += 1
    if test % 10000 ==0:
        print test

def vec(g,g1):
	for j in genefamily_numbers:
		for b in SFmatrix:
			for g in range(1,12):
				for g1 in range(1,12):
		
					return b[g],b[g1]
		print vec()

	def pearson_def(vec(g,g1)):
	    assert len(x) == len(y)
	    n = len(x)
	    assert n > 0
	    avg_x = average(x)
	    avg_y = average(y)
	    diffprod = 0
	    xdiff2 = 0
	    ydiff2 = 0
	    for idx in range(n):
		xdiff = x[idx] - avg_x
		ydiff = y[idx] - avg_y
		diffprod += xdiff * ydiff
		xdiff2 += xdiff * xdiff
		ydiff2 += ydiff * ydiff

	    return diffprod / math.sqrt(xdiff2 * ydiff2)





for i in genefamily_numbers:
    data_SFM.write(str(SFmatrix[i])+'\n' )
data_SFM.close()




