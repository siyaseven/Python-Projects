# PA Taylor, May 2013
# practice with image

from scipy import *
from pylab import *
import numpy.fft as fft
from ImageOps import grayscale
import Image
from random import gauss

eps=10**-5


# main ===============================================
if __name__ == "__main__":

	# read in image
	PICTURE=Image.open('WuGuangZhong_Tigers.jpg')
	im=array(grayscale(PICTURE))
	Lx, Ly = shape(im)
        
    	# x and y coordinates, with origin in center of image
    	xcoor = arange(-Lx/2,Lx/2)
    	ycoor = arange(-Ly/2,Ly/2)

        # make a noisy image
        im_noise = zeros( (Lx,Ly))
        N_SCL = im.std()

        for i in range(Lx):
                for j in range(Ly):
                        im_noise[i,j] = im[i,j] + 0.5*(gauss(0,1)*N_SCL)


        # make a simple LP filter
        # ??? HOW TO MAKE?

        # FFT
        IM = fft.fft2(im)
        IM_sh = fft.fftshift(IM) 
        IM_sh_LP = zeros( shape(IM_sh),dtype=complex )
	for k in range(Lx):
		for k1 in range(Ly):
			if 0.25*Lx<k<Lx*0.75 and Ly*0.25<k1<Ly*0.75:
				IM[k,k1] *= 0#IM_sh_LP

	IM_sh = fft.ifftshift(IM_sh)
	w = fft.ifft2(IM_sh)
        ######### plotting
        figure()
    	title('Image')
    	imshow(log10(eps+real(IM)), cmap=cm.gray, interpolation='nearest')
#    	imshow(abs(w), cmap=cm.gray, interpolation='nearest')
        figure('log10(FT of Image)')
    	imshow(log10(eps+abs(IM_sh)), cmap=cm.gray, interpolation='nearest')

        figure()
    	title('Noisy Image')
    	imshow(im_noise, cmap=cm.gray, interpolation='nearest')

        figure()
    	title('Image')
    	imshow(im, cmap=cm.gray, interpolation='nearest')

	show()
