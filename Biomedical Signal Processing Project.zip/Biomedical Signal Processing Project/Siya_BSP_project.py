"""
Siyabonga P Mthiyane 
Biomedical Signal Processing Project
BioMath Honours final project
Date: May 27 2013


"""

from scipy import *
from pylab import *
import numpy.fft as fft
import Image
from random import gauss

# dimensions of data slice + time
N = 144
dimx = 60 # 70-11+1
dimy = 67 # 74-8+1
# sampling rate
Ts = 2.5
fs = 1.0/Ts
T0 = N*Ts
f0=1.0/T0

# main ===============================================
if __name__ == "__main__":

	# read in reference time series called: refwav
	INFILE = file("Ref.1D", "r") 
        boxcar = [line.split() for line in INFILE]
        INFILE.close()
	refwav = zeros(N)
	for k in range(0,N):
		refwav[k] = boxcar[k][0]

        # read in set of brain time series data
        INFILE = file("AIMSftap.dat", "r")
	brain = [line.split() for line in INFILE]
	INFILE.close()

	# make array zero, and then fill in final form:  data
	data = zeros((dimx,dimy,N))
	n = 0
	for j in range(0,dimy):
                for i in range(0,dimx):
                        for k in range(0,N):
                                # don't need these values, but just keep track
                                x = brain[n][0]
                                y = brain[n][1]
                                z = brain[n][2]
                                data[i,j,k] = brain[n][3+k]
                                
                        n+=1 

	#example of initializing data set:
        firsttimept = zeros((dimx,dimy))

        # example of filling (NB: didn't *need* to initialize in this
        # Python case)
        firsttimept = data[:,:,0]
        n =0
        # making the image of mean,standard deviation, average power and correlation coefficients of each time sereis
        Ave = zeros((dimx,dimy))
        Ave1 =zeros((dimx,dimy))
        AveP =zeros((dimx,dimy))
        corr=zeros((dimx,dimy))
        FT = zeros((dimx,dimy))
        FT2 =zeros((dimx,dimy))
        for u in range(0,dimy):
              for u1 in range(0,dimx):
                  Ave[u1,u] = std(data[u1,u,:]) #calculating mean of each time series
                  Ave1 [u1,u] = mean(data[u1,u,:]) #calculating STD of each time series
                  AveP[u1,u]= sum((data[u1,u,:])**2)/N #calculating Average power using time series
                  Co = corrcoef(data[u1,u,:],refwav) #correlation of unfiltered frequencies
                  corr[u1,u]=Co[0,1] #obtaining/instoring coefficients in one 1D matrix

        #Calculating Fourier transform and filtering out some frequencies
        #correlation of two time series at zero lag
        corrFT = zeros((dimx,dimy))
        for u in range(0,dimy):
              for u1 in range(0,dimx):
                  FT = fft.fft(data[u1,u,:])
                  for g in range(len(FT)):
                      if not(0.01<g*f0<0.15 or (fs-0.15)<g*f0<(fs-0.01)):#
                          FT[g] = 0
                  FT2 = fft.ifft(FT)#transforming back to time series 
                  Co_FT = corrcoef(real(FT2),refwav)#correlation of filtered frequencies
                  corrFT[u1,u]=Co_FT[0,1]

        # example plotting/viewing
        figure('First time point image')
        title('Axial slice, eyes left')
    	imshow(firsttimept, cmap=cm.gray, interpolation='nearest')

        figure('A.pictuere of mean value of each time series')
        title('Axial slice, eyes left')
    	imshow(Ave1[:,:], cmap=cm.gray, interpolation='nearest')

        figure('B.picture of standard deviation of each time series')
        title('Axial slice, eyes left')
    	imshow(Ave[:,:], cmap=cm.gray, interpolation='nearest')

        figure('C.picture of Average Power of each time series')
        title('Axial slice, eyes left')
    	imshow(AveP, cmap=cm.gray, interpolation='nearest')

        figure('D.picture of cross correlation  of each time series')
        title('Axial slice, eyes left; unfilt')
    	imshow(corr, cmap=cm.gray, vmin=-1,vmax=1,interpolation='nearest')

        figure('E.picture of filtered cross correlation coefficients of')
        title('Axial slice, eyes left; FILT')
    	imshow(corrFT, cmap=cm.gray, vmin=-1,vmax=1,interpolation='nearest')

        figure('reftimeseries')
        title('Functional paradigm: boxcar; normalized example time series')
        plot(refwav)

        # example of ~normalized time series
        examp = (data[dimx/2,dimy/2,:]-mean(data[dimx/2,dimy/2,:]))/std(data[dimx/2,dimy/2,:])
        plot(examp)
        ylim([1.1*min(examp),1.1*max(examp)])
        xlim([0, len(examp)])

        show()
