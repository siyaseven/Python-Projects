"""
Siyabonga P Mthiyane
BSP Assignment 1b, Question 5
Date: May 21 2013
"""
import scipy
import pylab as pl
from math import*

T0 = 2.0
k =1
t = pl.linspace(-T0/2,T0/2,100)
g_t = pl.zeros(len(t), dtype = float)
global g_t,t

#ploting g(t) approximated
def Kvalues(k_l,k_u,nr):
	""" ploting g(t) with k values between K_l < k < k_u """
	g_t = pl.zeros(len(t), dtype = float)
	for k in range(k_l,k_u,2):
		for i in range(len(t)):
			g_t[i] +=(4.0/(pi*k)*sin(2.0*pi*k*t[i]/T0))
	pl.subplot(5,2,nr)#creating matrix of graphs
	pl.xlabel('t')
	pl.ylabel('g(t)')
	pl.title(" %d<k<%d" %(k_l,k_u))
	pl.plot(t,g_t)

#ploting the original function
def g_T(tt): # input is ARRAY of time values
	""" ploting the original function so to campare with approximated g(t) for different K """
	gT = pl.zeros(len(tt))
	for j in range(len(tt)):
		if -T0/2<tt[j]<0:
			gT[j] = -1
		elif 0<tt[j]<T0/2:
			gT[j]= 1
	return gT

if __name__ == "__main__":
	#ploting graphs with different values of k 
	Kvalues(1,5,1)
	pl.plot(t,g_T(t))
	Kvalues(1,11,2)
	pl.plot(t,g_T(t))
	Kvalues(1,25,3)
	pl.plot(t,g_T(t))
	Kvalues(1,75,4)
	pl.plot(t,g_T(t))
	Kvalues(3,75,5)
	pl.plot(t,g_T(t))
	Kvalues(7,75,6)
	pl.plot(t,g_T(t))
	Kvalues(13,75,7)
	pl.plot(t,g_T(t))
	Kvalues(25,75,8)
	pl.plot(t,g_T(t))
	pl.subplots_adjust(hspace = 0.9) #puting space between graphs
	pl.subplot(5,2,9)
	pl.plot(t,g_T(t))
	for i in range(len(t)):
		g_t[i] +=(4.0/(pi*k)*sin(2.0*pi*k*t[i]/T0))
	pl.plot(t,g_t)
	pl.plot(t,g_T(t))
	pl.show()







