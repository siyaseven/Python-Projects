'''
Siyabonga P Mthiyane
BSP Assignment 1b, Question 5
Date: May 21 2013

plotting output of difference equation,input equation
y[n] = SUM{k=0:5}(b_k * x[n-k] ) 

calculate impulse response, h[n] from diff eq given above

'''

# import as necessary
#from __future__ import division
from scipy import *
from pylab import *
from matplotlib import *
import random

def make_input(n):
    ''' 
    to start, this is our specific 'input signal', which we can 
    make whatever we want
    '''
    if( n < 4 ):
        out = 1.0
    else:
        out = 0
    return out

#simple input delta 
def delta_input(n):
	""" simple function calculating for h[n] """
	if n ==0:
		deL = 1
	else:
		deL =0

	return deL

#first input 
def Makea_input(n):
	""" input calculation for part (a) in Q4  """
	if n >= 0:
		X_n = sin(2.0*n*pi/25)+0.5*(random.uniform(0,1)-0.5)
	else:
		X_n = 0
	return X_n
#second input
def Makeb_input(n):
	"""input calculatiion for part (b) Q4 """
	if n >= 0:
		X_n = sin(2.0*n*pi/25)+0.5*sin(2.0*n*pi/6.5)
	else:
		X_n = 0
	return X_n

# main ===============================================
if __name__ == "__main__":

    # define range of n's to walk through; should only have y>0 for n>=0
    NMAX = 150

    N = 5 # some number of non-zero b_k components
    # component coefs up to M, specific to wave
    b = [1.0/6,1.0/6,1.0/6,1.0/6,1.0/6,1.0/6]

    ns = arange(0,NMAX+1) # our array of n's: time values

    # make an array of zeros which will be filled in 
    # for the x[n-k] and y[n-k], should have same number of 
    # spaces as our n's to test
    y = zeros(len(ns),dtype=float)
    # to record our x-inputs
    x = zeros(len(ns),dtype=float)
    d = zeros(len(ns),dtype=float)
    # !!!!!! will need to define below-- right now just stays zeros
    h = zeros(len(ns),dtype=float)
    h1 = zeros(len(ns),dtype=float)
    ho = zeros(len(ns),dtype=float) # h[n] output
    # go through and make input array from func above.
    # loop through each point in our range of `n'
    for n in ns:
        x[n] = Makea_input(n)
        d[n] = Makeb_input(n)

    # loop through each time point
    for n in ns:
        # loop through all b_k components
        for k in range(0,N+1): 
            # switch to maintain causality! no response in negative time
            # like initial condition: all x[n<0]==0.
            if( not(n-k < 0) ): 
                y[n]+= b[k]*x[n-k]
                h[n]+= b[k]*d[n-k]
                ho[n]+= b[k]*delta_input(n-k)


    # plot limits for x
    absci = [-0.5, NMAX+0.5]

    # plots
    subplot(511)
    xlabel( "n") # these plot format commands must be *below* 'subplot',
                 # as I was kindly informed by AIMS students
    ylabel( "x_a[n]")
    xlim(absci)
    ylim([1.2*min(x)-0.1, 1.2*max(x)]) # so we see all of graph
    stem(ns,x, linefmt='k-', markerfmt='bo', basefmt='k-')

    # plots
    subplot(512)
    xlabel( "n") # these plot format commands must be *below* 'subplot',
                 # as I was kindly informed by AIMS students
    ylabel( "x_b[n]")
    xlim(absci)
    ylim([1.2*min(d)-0.1, 1.2*max(d)]) # so we see all of graph
    stem(ns,d, linefmt='k-', markerfmt='bo', basefmt='k-')

    # plots
    subplot(513)
    xlabel( "n") # these plot format commands must be *below* 'subplot',
                 # as I was kindly informed by AIMS students
    ylabel( "y_a[n]")
    xlim(absci)
    ylim([1.2*min(h)-0.1, 1.2*max(h)+0.1]) # so we see all of graph
    stem(ns,y,linefmt='k-', markerfmt='ro', basefmt='k-')

    # plots 
    subplot(514)
    xlabel( "n")
    ylabel( "y_b[n]")
    xlim(absci)
    ylim([1.2*min(y)-0.1, 1.2*max(y)])
    stem(ns,h,linefmt='k-', markerfmt='go', basefmt='k-')

    # plots 
    subplot(515)
    xlabel( "n")
    ylabel( "h[n]")
    xlim(absci)
    ylim([1.2*min(ho)-0.1, 1.2*max(ho)])
    stem(ns,ho,linefmt='k-', markerfmt='go', basefmt='k-')

    show()

