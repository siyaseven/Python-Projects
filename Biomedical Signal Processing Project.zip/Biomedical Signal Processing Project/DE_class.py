# BSP class, PA Taylor

'''
AIMS-Senegal, March 2013.  Biomedical Signal Processing Course


plotting response as defined by difference equation:
y[n] = SUM{k=0:N}(b_k * x[n-k] ) - SUM{k=1:M}(a_k * y[n-k])

Editing to be done by student:  
+ write in what form our impulse function (delta-function) would take

+ calculate impulse response, h[n] from diff eq given below


'''

# import as necessary
#from __future__ import division
from scipy import *
from pylab import *
from matplotlib import *


def make_input(n):
    ''' 
    to start, this is our specific 'input signal', which we can 
    make whatever we want
    '''
    if( n < 4 ):
        out = 1.0
    else:
        out = 0
    return out

def delta_input(n):

	if n ==0:
		deL = 1
	else:
		deL =0

	return deL


# main ===============================================
if __name__ == "__main__":
    
    # define range of n's to walk through; should only have y>0 for n>=0
    NMAX = 10

    
    M = 2 # some number of non-zero a_k components
    # component coefs up to N, specific to wave; a_0 == 1, by convention
    a = [1,  0,  0]  # so that a[1] = a_1, and a[2] = a_2, etc.


    N = 2 # some number of non-zero b_k components
    # component coefs up to M, specific to wave
    b = [1.0/3,1.0/3,  1.0/3]

    #!!! programming question: how might it be smarter to define M and
    #!!! N above, given their sol meaning as max index of a and b,
    #!!! respectively?


    ns = arange(0,NMAX+1) # our array of n's: time values

    # make an array of zeros which will be filled in 
    # for the x[n-k] and y[n-k], should have same number of 
    # spaces as our n's to test
    y = zeros(len(ns),dtype=float)
    # to record our x-inputs
    x = zeros(len(ns),dtype=float)
    d = zeros(len(ns),dtype=float)
    # !!!!!! will need to define below-- right now just stays zeros
    h = zeros(len(ns),dtype=float)

    # go through and make input array from func above.
    # loop through each point in our range of `n'
    for n in ns:
        x[n] = make_input(n)
        d[n] = delta_input(n)

    ######### Difference Equation in Action!

    # loop through each time point
    for n in ns:
        # loop through all b_k components
        for k in range(0,N+1): 
            # switch to maintain causality! no response in negative time
            # like initial condition: all x[n<0]==0.
            if( not(n-k < 0) ): 
                y[n]+= b[k]*x[n-k]
                h[n]+= b[k]*delta_input(n-k) #d[n-k]
        # loop through all a_k components and add them in, IF causal
        for k in range(1,M+1): 
            # switch to maintain causality! no response in negative time
            # like initial condition: all y[n<0]==0.
            if( not(n-k < 0) ): 
                # we subtract each one by convention of written eq.
                y[n]-= a[k]*y[n-k]
                h[n]-= a[k]*h[n-k]




    # plot limits for x
    absci = [-0.5, NMAX+0.5]

    

    # plots
    subplot(311)
    xlabel( "n") # these plot format commands must be *below* 'subplot',
                 # as I was kindly informed by AIMS students
    ylabel( "x[n]")
    xlim(absci)
    ylim([1.2*min(x)-0.1, 1.2*max(x)]) # so we see all of graph
    stem(ns,x, linefmt='k-', markerfmt='bo', basefmt='k-')

    # plots
    subplot(312)
    xlabel( "n") # these plot format commands must be *below* 'subplot',
                 # as I was kindly informed by AIMS students
    ylabel( "????????h[n]???????")
    xlim(absci)
    ylim([1.2*min(h)-0.1, 1.2*max(h)+0.1]) # so we see all of graph
    stem(ns,h,linefmt='k-', markerfmt='ro', basefmt='k-')



    subplot(313)
    xlabel( "n")
    ylabel( "y[n]")
    xlim(absci)
    ylim([1.2*min(y)-0.1, 1.2*max(y)])
    stem(ns,y,linefmt='k-', markerfmt='go', basefmt='k-')

    show()


