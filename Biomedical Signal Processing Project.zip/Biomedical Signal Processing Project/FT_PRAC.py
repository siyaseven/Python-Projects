# PA Taylor, May 2013
# practice with image

from scipy import *
from pylab import *
import numpy.fft as fft
from ImageOps import grayscale
import Image
from random import gauss

eps=10**-5
T0=5
t = linspace(-T0/2,T0/2,128)
g_t = zeros(len(t), dtype = float)
global g_t,t
def TimeSeriesFunc(t): # use scalar input
    # just in case we plot more than one period around zero
    
    if( t<0 ):
        return -1 #t**2
    else:
        return 1 #-t**2

#ploting g(t) approximated
#def Kvalues(k_l,k_u,nr):
#	""" ploting g(t) with k values between K_l < k < k_u """
#	g_t = zeros(len(t), dtype = float)
#	for k in range(k_l,k_u,2):
#		for i in range(len(t)):
#			g_t[i] +=(4.0/(pi*k)*sin(2.0*pi*k*t[i]/T0))
#	#subplot(5,2,nr)#creating matrix of graphs
#	xlabel('t')
#	ylabel('g(t)')
#	title(" %d<k<%d" %(k_l,k_u))
#	plot(t,g_t)


# main ===============================================
if __name__ == "__main__":

        N0 = 128
        t = linspace(-T0/2.,T0/2.,N0)
        f1 = zeros(len(t))
        for i in range(len(t)):
                f1[i] = TimeSeriesFunc( t[i] )

        F1 = fft.fft(f1)

	VAL = 40
        for j in range(len(F1)):
		if j <= VAL or j>=N0-1-VAL:
			F1[j] = 0

        F1b = fft.fftshift(F1)
        ff = fft.ifft(F1)


        figure()
        title('FFT')
        plot(t,abs(ff)*sign(real(ff)))#,'bo-')
	plot(t,f1)


        figure()
        title('FFT')
        plot(abs(F1),'bo-')

        figure()
        title('FFT (shifted)')
        plot(abs(F1b),'bo-')

#        figure()
#        title('function')
        #Kvalues(40,128,1)
#        plot(t,f1)#+plot(t,g_t)

	show()


