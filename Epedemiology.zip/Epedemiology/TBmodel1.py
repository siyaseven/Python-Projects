import csv
from numpy import *
import pylab
from scipy.integrate import odeint

#Time options
dt = 1/12.
t_start = 0.0
t_final = 100
 
# Number of time steps: 1 extra for initial condition
steps = floor((t_final - t_start)/dt)
time=x = linspace(0,t_final,steps+1)

#Initial model values
S0=9999
L0=1
D0=0
y_init=[S0,L0,D0]
N=S0+L0+D0 # Initial total population size

#parameters 
Beta=10 #transmision parameter
Mu=0.02  #natural mortality rate
Omega=0.02  #Birth/recruitment rate
Gamma=0.05 #TB progression rate
Sigma=0.21  #natural cure rate 
Alpha=0.23  #mortality rate due to TB

#=============================================================
def derivatives(y,t):
    
    #Dfine derivative array
    number_of_derivs=3
    deriv=zeros((number_of_derivs))
    #Assign variable names
    S=y[0]
    L=y[1]
    D=y[2]
    
    #S
    deriv[0]=Omega*N - Beta*S*D/N - Mu*S
    #Lf
    deriv[1]=Beta*S*D/N  - Mu*L - Gamma*L + Sigma*D
    #D
    deriv[2]= Gamma*L - Mu*D - Alpha*D - Sigma*D

    return deriv

#Solve the ODE
ODE_solution=odeint(derivatives,y_init,time)

#plot results
pylab.plot(x,ODE_solution[:,0], label='S',linewidth=3,color='b')
pylab.plot(x,ODE_solution[:,1], label='L',linewidth=3,color='g')
pylab.plot(x,ODE_solution[:,2], label='D',linewidth=3,color='r')

pylab.legend(loc='best')
pylab.show()


#Calculating population propotions
i=x.tolist().index(25) #get time index for 15 years

Proportion_D=ODE_solution[i,2]/(sum(ODE_solution[i,:])) # calculate the proportion
print 'The proportion with active TB disease is: ', round(Proportion_D,2)

Proportion_L=ODE_solution[i,1]/(sum(ODE_solution[i,:])) # calculate the proportion
print 'The proportion with latent TB is: ', round(Proportion_L,2)


