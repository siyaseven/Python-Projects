#=========================================================
# Python codes for an SIR model with transient demographics
# dS/dt = P(t)-lambda*S*I/N; dI/dt = lambda*S*I/N + gamma*I; dR/dt = gamma*I
#where P(t) is a step function
# Written by:     Last modified: 01/04/2014 
#=========================================================

from numpy import *
import pylab
from scipy.integrate import ode, odeint

##############################################################

def P(t):
    #define the step function
    if t>start_t and t<=stop_t:
        return alpha
    else:
        return 0
#solve the system dy/dt=f(y,t)
def derivatives(y,t):
    number_of_derivs=3
    deriv=zeros((number_of_derivs))
    
    St=y[0]
    It=y[1]
    Rt=y[2]

    #Total population
    N=St+It+Rt

    #the model equations
    deriv[0]=P(t)-Lambda*St*It/N
    deriv[1]=Lambda*St*It/N-gamma*It
    deriv[2]=gamma*It
       
    return deriv

#Time options
dt = 1/100.
t_start = 0.0
t_final = 5
steps = floor((t_final - t_start)/dt) # Number of time steps: 1 extra for initial condition
time=x = linspace(0,t_final,steps+1)

#Initial conditions
S0=94
I0=6
R0=0
y_init=[S0,I0,R0]

#The parameters
Lambda=10
gamma=3
alpha=25
start_t=1
stop_t=2

#Solve the ODE
ODE_solution=odeint(derivatives,y_init,time)

#plot results
pylab.plot(x,ODE_solution[:,0], label='S',linewidth=3,color='b')
pylab.legend(loc='best')
pylab.show()
pylab.plot(x,ODE_solution[:,1], label='I',linewidth=3,color='g')
pylab.legend(loc='best')
pylab.show()
pylab.plot(x,ODE_solution[:,2], label='R',linewidth=3,color='r')
pylab.legend(loc='best')
pylab.show()


