#!/usr/bin/env python


# The above allows this script to be run directly from the shell
# Python codes to solve an SIR model: dy    dS = mu * N - beta * I * S / N - mu *S,
#dI = beta * I * S / N - (gamma + mu) * I, and  dR = gamma * I - mu * R
#Last modified: 01/04/2014
#Written by AM Lambi, T Mugwagwa, and M Ndeffo
#================================================================


# This loads some pacakges that have arrays etc and the ODE integrators
import scipy, scipy.integrate


# Define yor Parameters here
beta = 0.5        #
gamma = 0.2
b= 0.0001
z=10
d=0.33
K=1000000.0
#mu = 1.0 / 50 # Natural mortality rate as 1/life expectancy(# Warning!  int / int = int, e.g. 1 / 50 = 0.)

# Give your Initial conditions
S0 = 9999.0 # initial proportion of susceptibles
I0 = 1.0 # initial proportion of infective individuals
R0 = 0.00 # initial proportion of recovered individuals
B0 = 0.00
# Your initial conditions should be written in a vector, because your results will be writen in this form
Y0 = [ S0, I0, R0, B0 ] 

tMax = 100 # Define your maximum time for your simulations

# Time vector for solution
T = scipy.linspace(0, tMax, 1001)


# This defines a function that is the right-hand side of the ODEs
# Warning!  Whitespace at the begining of a line is significant!
def rhs(Y, t, beta, gamma,b,z,d,K):
    '''
    SIR model.
    
    This function gives the right-hand sides of the ODEs.
    '''
    
    # Convert vector to meaningful component vectors
    # Note: Indices start with index 0, not 1!
    S = Y[0]
    I = Y[1]
    R = Y[2]
    B = Y[3]
    N = S + I + R + B
    
    # The right-hand sides
    DS = b*N-b*S-(beta*S*B)/(B+K)
    DI = (beta*S*B)/(B+K)-b*I-gamma*I
    DR = gamma*I-b*R
    DB = z*I-d*B
#    dS = mu * N - beta * I * S / N - mu * S
#    dI = beta * I * S / N - (gamma + mu) * I
#    dR = gamma * I - mu * R
    
    # Convert meaningful component vectors into a single vector
    #dY = [ dS, dI, dR ]
    DY = [ DS, DI, DR, DB]
    return DY

# Integrate the ODE
# Warning!  The ODE solver over-writes the initial value.
# This can be a pain in the ass if you run the ODE multiple times.
# Also, 'args' passes parameters to right-hand-side function.
solution = scipy.integrate.odeint(rhs,
                                  Y0,
                                  T,
                                  args = (beta, gamma, b, z, d, K))
        
S = solution[:, 0]
I = solution[:, 1]
R = solution[:, 2]
B = solution[:, 3]
N = S + I + R + B


# Make plots

# Load a plotting package
# PyLab is motivated by Matlab...
import pylab

pylab.figure() # calls the figure invironment
pylab.plot(T, S ,
           T, I,
           T, R,
           T, B)
pylab.xlabel('Time')
pylab.ylabel('Proportion')

pylab.legend([ 'Susceptible', 'Infective', 'Recovered'])#, 'Bacteria' ])

# Actually display the plot
pylab.show()
