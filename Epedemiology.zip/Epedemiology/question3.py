#!/usr/bin/env python

# The above allows this script to be run directly from the shell
# Python codes to solve an SIR model: dy    dS = mu * N - beta * I * S / N - mu *S,
#dI = beta * I * S / N - (gamma + mu) * I, and  dR = gamma * I - mu * R
#Written by AM Lutambi, T Mugwagwa, and M Ndeffo
#Last modified by: Siyabonga, Princess and Others
#================================================================

# This loads some pacakges that have arrays etc and the ODE integrators
import scipy, scipy.integrate
from numpy import *
import pylab # Load a plotting package
from scipy.integrate import ode, odeint

# Define yor Parameters here

N=10000
b=0.0001
KL=1.0e6
beta =1
gamma = 0.2
deltaL=0.33
epsilon=10
par=[ N, b, beta, KL, gamma, deltaL, epsilon]

# Give your Initial conditions
S0 = 9999# initial proportion of susceptibles
I0 =  1# initial proportion of infective individuals
B0 = 0.00 # initial proportion of recovered individuals

# Your initial conditions should be written in a vector, 
#because your results will be writen in this form
Y0 = [ S0, I0, B0 ]

tMax = 2000 # Define your maximum time for your simulations

# Time vector for solution
T = scipy.linspace(0, tMax, tMax)

# This defines a function that is the right-hand side of the ODEs
def rhs(Y, t, N, b, beta, KL, gamma, deltaL, epsilon):
	'''
	SIR model.
	This function gives the right-hand sides of the ODEs.
	'''
	# Convert vector to meaningful component vectors
	# Note: Indices start with index 0, not 1!
	S = Y[0]
	I = Y[1]
	B = Y[2]
	N = S + I + B
	# The right-hand sides
	dS = b * N - b*S -beta * S * B / (B+KL)
	dI = beta * S * B / (B+KL)-b* I-gamma* I
	dB = epsilon * I - deltaL * B
	# Convert meaningful component vectors into a single vector
	dY = [ dS, dI, dB ]
	return dY

# Integrate the ODE
#'args' passes parameters to right-hand-side function.
solution = scipy.integrate.odeint(rhs,
                                  Y0,
                                  T,
                                  args = (N, b, beta, KL, gamma, deltaL, epsilon))
S = solution[:, 0]
I = solution[:, 1]
B = solution[:, 2]

pylab.figure() # calls the figure invironment
pylab.plot(T, I,linewidth=1,color='k')
pylab.xlabel('Time(days)')
pylab.xlim(xmin=0)
pylab.ylabel('Infected')

def P(t):
	#define the step function
	if t<21:
		return 0
	else:
		return alpha

#solve the system dy/dt=f(y,t)
def derivatives(y,t):
	number_of_derivs=3
	deriv=zeros((number_of_derivs))
	St=y[0]
	It=y[1]
	Bt=y[2]
	#Total population
	#the model equations
	deriv[0]= b * N - b*St -(1-P(t))*beta * St * Bt / (Bt+KL)
	deriv[1]=(1-P(t))*beta * St * Bt / (Bt+KL)-b* It-gamma* It
	deriv[2]=epsilon * It - deltaL * Bt
	return deriv

#Changing water cleanliness
def derivatives2(y,t):
	number_of_derivs2=3
	deriv2=zeros((number_of_derivs2))
	St=y[0]
	It=y[1]
	Bt=y[2]
	#the model equations
	deriv2[0]= b * N - b*St -beta * St * Bt / (Bt+KL)
	deriv2[1]=(1-P(t))*beta * St * Bt / (Bt+KL)-b * It-gamma* It
	deriv2[2]=epsilon * It - deltaL * Bt
	return deriv2

#Time options
dt = 1
t_start = 0
t_final = 730
steps = floor((t_final - t_start)/dt) # Number of time steps: 
#1 extra for initial condition
time=x = linspace(0,t_final,steps+1)

#Initial conditions
S0=9999
I0=1
B0=0
y_init=[S0,I0,B0]

#The parameters
N=10000
b=0.0001
KL=1.0e6
beta =1
gamma = 0.2
deltaL=0.33
epsilon=10
alpha =0.2

#Solve the ODE
ODE_solution=odeint(derivatives,y_init,time)
ODE_solution2=odeint(derivatives2,y_init,time)

#plot results
pylab.plot(x,ODE_solution[:,1], label='I',linewidth=1,color='g')
pylab.plot(x,ODE_solution2[:,1],'m--',linewidth=3)
pylab.legend([ 'Personal hygiene after 3 weeks'])

def P(t):
	#define the step function
	if t<112:
		return 0
	else:
		return alpha
#solve the system dy/dt=f(y,t)

#Personal hygiene
def derivatives(y,t):
	number_of_derivs=3
	deriv=zeros((number_of_derivs))
	St=y[0]
	It=y[1]
	Bt=y[2]
	#the model equations
	deriv[0]= b * N - b*St -beta * St * Bt / (Bt+KL)
	deriv[1]=beta * St * Bt / (Bt+KL)-b* It-gamma* It
	deriv[2]=(1-P(t))*epsilon * It - deltaL * Bt
	return deriv

#Changing water cleanliness
def derivatives2(y,t):
	number_of_derivs2=3
	deriv2=zeros((number_of_derivs2))
	St=y[0]
	It=y[1]
	Bt=y[2]
	#the model equations
	deriv2[0]= b * N - b*St -beta * St * Bt / (Bt+KL)
	deriv2[1]=(1-P(t))*beta * St * Bt / (Bt+KL)-b * It-gamma* It
	deriv2[2]=epsilon * It - deltaL * Bt
	return deriv2

#Time options
dt = 1
t_start = 0
t_final = 730
steps = floor((t_final - t_start)/dt) # Number of time steps: 
#1 extra for initial condition
time=x = linspace(0,t_final,steps+1)

#Initial conditions
S0=9999
I0=1
B0=0
y_init=[S0,I0,B0]

#The parameters
N=10000
b=0.0001
KL=1000000
beta =1
gamma = 0.2
deltaL=0.33
epsilon=10
alpha =0.2

#Solve the ODE
ODE_solution=odeint(derivatives,y_init,time)
ODE_solution2=odeint(derivatives2,y_init,time)

#plot results
pylab.plot(x,ODE_solution[:,1], label='I',linewidth=1,color='y')
pylab.plot(x,ODE_solution2[:,1],'r+',linewidth=1)
pylab.legend(['Pre-intervention','Increasing(epsilon) after 3 weeks',
'Increasing(beta) after 3 weeks','Increasing(epsilon) after 16 weeks',
'Increasing(beta) after 16 weeks'])
pylab.xlim(xmax=730)
pylab.show()
