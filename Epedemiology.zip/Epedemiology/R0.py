import math

#The parameters
N=10000
b=0.0001
KL=1000000
beta =1
gamma = 0.2
deltaL=0.33
epsilon=10
alpha =0.2

























